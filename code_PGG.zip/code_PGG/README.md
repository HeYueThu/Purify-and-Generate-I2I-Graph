# PGG

This is implementation for our KDD 2021 paper:

He Y ,  Dong Y ,  Cui P , et al. Purify and Generate: Learning Faithful Item-to-Item Graph from Noisy User-Item Interaction Behaviors.  2021.

## Enviroments

```
python==3.7.9
pytorch==1.6.0
pytorch-ligtning==1.0.6
torch-geometric==1.6.1
tqdm==4.51.0
pandas==1.3.4
numpy==1.21.2
scikit-surprise==1.1.1
```

## Simulation Dataset
We provide processed simulation dataset in `data` folder. 

### Running
Run our model GPBG on simulation dataset:

```
cd code
python sim-main.py
```

The corresponding results are shown in Table 2 in the paper.


## Hyper parameters

The used hyperparameter has been written in the python file.