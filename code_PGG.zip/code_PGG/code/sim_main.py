import numpy as np
import torch
from torch_geometric.data import Data

from torch.utils.data import DataLoader

from model_util.model import GRFModel
from model_util.datamodel import TestSetDataset, SetDataset
from pytorch_lightning import Trainer

def DivD(G):
    E = []
    A = []
    for raw in G:
        E.append([raw[0], raw[1]])
        A.append([raw[2]])
    return np.array(E), np.array(A)


def readD(path, num_item):
    data = np.load(path, allow_pickle=True)

    Set_Y0 = []
    X0 = []
    for key, values in data.item()['0_train'].items():
        Set_Y0.append(values)
        X0.append(key)
    X0 = np.array(X0)
    Set_Y0 = np.array(Set_Y0)

    Graph_V = []
    for i in range(num_item):
        Graph_V.append(data.item()['emb'][data.item()['order'][i]])
    Graph_V = np.array(Graph_V)

    Graph_E0, Graph_A0 = DivD(data.item()['0_graph'])

    Graph_V = torch.tensor(Graph_V, dtype=torch.float)
    Graph_E0 = torch.tensor(Graph_E0.transpose(), dtype=torch.long)
    Graph_A0 = torch.tensor(Graph_A0, dtype=torch.float).reshape(-1)

    G0 = Data(x=Graph_V, edge_index=Graph_E0, edge_attr=Graph_A0)

    return X0, Set_Y0, G0



def main():
    weighted = False
    data_train = "../data/Dataset_1_2_2.npy"
    data_test = "../data/Dataset_1_2_2.npy"
    num_item = 100
    batch_size = 256
    
    Y, X, G = readD(data_train, num_item)
    # set to dataloader
    datasetrain = SetDataset(X, Y, num_item, weighted=weighted)

    train_dataloader = DataLoader(datasetrain, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=True)
    # weight copy tensor
    edge_weight_ = torch.FloatTensor(G.edge_attr.shape)
    edge_weight_.copy_(G.edge_attr)
    # init g2 graph data as GS
    graph = Data(x=G.x, edge_index=G.edge_index, edge_attr=edge_weight_)

    
    test = np.load(data_test, allow_pickle=True).item()['0_test']
    X = []
    Y = []
    for key, values in test.items():
        X.append(values)
        Y.append(key)
    X = np.array(X)
    Y = np.array(Y)
    datasetest = TestSetDataset(X, Y, num_item)
    test_dataloader = DataLoader(datasetest, batch_size=256, shuffle=True, num_workers=0, pin_memory=True)

    # if not os.path.exists('result'):
    #     os.system('mkdir {0}'.format('result'))

    model = GRFModel(input_channels=16, output_channels=16, num_layer=2, latent_channels=16,
                     num_item=num_item,
                     graph=graph,
                     alpha=0.01, topk=10,
                     aggr='add', directed=False)
    trainer = Trainer(max_epochs=10)
    trainer.fit(model, train_dataloader)
    trainer.test(model, test_dataloader)

if __name__ == '__main__':
    main()
