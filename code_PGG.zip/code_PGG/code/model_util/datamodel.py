import numpy as np
import pandas as pd
from torch.utils.data.dataset import Dataset
import torch
from model_util.Data import Weights


class SetDataset(Dataset):
    def __init__(self, X, Y, item_size, weighted=False, edges=None):
        super(SetDataset, self).__init__()
        self.X = X
        self.Y = Y
        self.n = len(self.Y)
        self.item_size = item_size
        self.weighted = weighted
        self.weights = Weights()
        if weighted:
            self.weights.train(edges)

    def __len__(self):
        return self.n

    def __getitem__(self, index):
        np.random.seed(666)
        row = self.X[index]
        if self.weighted:
            lists = self.sample_weight(row, weights=self.weights.getweight(self.Y[index], row), size=len(row))
        else:
            lists = np.array(row)
        nsp = torch.zeros(self.item_size)
        for i in lists:
            nsp[i] = nsp[i] + 1
        return self.Y[index], nsp

    def sample_uniform(self, user_play_list, size):
        user_sample = np.random.choice(user_play_list, size=size, replace=True)
        return user_sample

    def sample_weight(self, user_play_list, weights, size):
        user_sample = np.random.choice(user_play_list, size=size, replace=True, p=weights)
        return user_sample


class TestSetDataset(Dataset):
    def __init__(self, X, Y, item_size):
        super(TestSetDataset, self).__init__()
        self.X = X
        self.Y = Y
        self.n = len(self.Y)
        self.item_size = item_size
        self.targets = []
        for i in range(len(X)):
            lists = self.X[i]
            target = lists[np.random.randint(0, len(lists))]
            self.targets.append(target)

    def __len__(self):
        return self.n

    def __getitem__(self, index):
        lists = self.X[index]
        target = self.targets[index]
        nsp = torch.zeros(self.item_size + 1)
        nsp[lists] = 1
        nsp[-1] = target
        return self.Y[index], nsp
