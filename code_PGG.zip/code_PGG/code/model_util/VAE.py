import torch
import torch.nn as nn
from torch.nn import functional as F
import pytorch_lightning as pl


class VAE(pl.LightningModule):

    def __init__(self, output_channels, latent_dims,  num_items):
        super(VAE, self).__init__()

        self.encoder = nn.Sequential(
            nn.Linear(output_channels, output_channels),
            nn.ReLU(),
            nn.BatchNorm1d(output_channels, momentum=0.9)
        )
        self.fc_mu = nn.Linear(output_channels, latent_dims)
        self.fc_var = nn.Linear(output_channels, latent_dims)
        self.decoder = nn.Sequential(
            nn.Linear(output_channels + latent_dims, output_channels),
            nn.ReLU(),
            nn.BatchNorm1d(num_items, momentum=0.9),
            nn.Linear(output_channels, 1)
        )
        self.latent_dims = latent_dims


    def encode(self, input):
        result = self.encoder(input)
        # result = torch.flatten(result, start_dim=1)

        # Split the result into mu and var components
        # of the latent Gaussian distribution
        mu = self.fc_mu(result)
        log_var = self.fc_var(result)

        return mu, log_var

    def decode(self, x, noise):
        x = x.reshape(1, x.shape[0], x.shape[1])
        x = x.expand(noise.shape[0], -1, -1)
        noise = noise.reshape(noise.shape[0], 1, noise.shape[1])
        noise = noise.expand(-1, x.shape[1], -1)
        res = self.decoder(torch.cat((x, noise), 2))
        output = F.softmax(res, dim=1)
        return output

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return eps * std + mu
