import torch.nn as nn
import torch.nn.functional as F
from pytorch_lightning.core.lightning import LightningModule
from torch_geometric.nn import GatedGraphConv, GCNConv


class GCN(LightningModule):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """

    def __init__(self, in_features, out_features, num_layers, aggr='add', directed=False):
        super(GCN, self).__init__()
        self.G = nn.ModuleList()
        self.B = nn.ModuleList()
        self.directed = directed
        self.num_layers = num_layers
        self.in_features = in_features
        self.out_features = out_features
        self.aggr = aggr

        if self.directed:
            ggnn = GatedGraphConv(self.out_features, self.num_layers, self.aggr)
            ggnn.reset_parameters()
            self.G.append(ggnn)
            self.B.append(nn.BatchNorm1d(self.out_features, momentum=0.9))
        else:
            for i in range(self.num_layers):
                if i == 0:
                    conv = GCNConv(self.in_features, self.out_features)
                else:
                    conv = GCNConv(self.out_features, self.out_features)
                conv.reset_parameters()
                self.G.append(conv)
                self.B.append(nn.BatchNorm1d(self.out_features, momentum=0.9))

    def forward(self, data):
        x, edge_index, edge_weight = data.x, data.edge_index, data.edge_attr
        for g, b in zip(self.G, self.B):
            x = g(x, edge_index, edge_weight)
            if self.directed:
                return x
            x = b(F.relu(x))
        return x