import torch
import numpy as np
from pytorch_lightning.core.lightning import LightningModule
from torch.nn import functional as F
from torch import nn
from torch.optim import SGD

from model_util.GCN import GCN
from model_util.VAE import VAE
from model_util.utils import acc, clip_gradient
from deeprobust.graph.defense.pgd import PGD, prox_operators
from torch_geometric.utils import to_dense_adj


class GRFModel(LightningModule):
    def __init__(self, input_channels, output_channels, num_layer, latent_channels, num_item,
                 graph, alpha=0.1, topk=30,
                 aggr='add', directed=False):
        super(GRFModel, self).__init__()
        self.gcn = GCN(in_features=input_channels, out_features=output_channels, num_layers=num_layer, aggr=aggr,
                       directed=directed)
        self.seg = VAE(output_channels=output_channels, latent_dims=latent_channels, num_items=num_item)
        self.graph = graph

        self.graph.edge_attr.requires_grad = False
        self.alpha = alpha
        self.topK = topk
        self.num_item = num_item
        self.emb = None

    def forward(self, input):
        x = self.gcn(self.graph)
        input = input / input.sum(1).reshape(-1, 1)
        mu, logvar = self.seg.encode(input.mm(x))
        z = self.seg.reparameterize(mu, logvar)
        output = self.seg.decode(x, z)
        return output.squeeze().unsqueeze(1), mu.unsqueeze(1), logvar.unsqueeze(1)

    def lossv(self, inputs, target, E):
        '''
        negative log likelihood loss.
        :param inputs:
        :param target:
        :param E:
        :return:
        '''
        eps = 1e-12
        return - ((inputs.select(1, E) + eps).log() * target).sum(1).mean()

    def lossk(self, mu, logvar):
        '''
        vae loss of mu and logvar
        :param mu:
        :param logvar:
        :return:
        '''
        return - 0.5 * (1 + logvar - mu.pow(2) - logvar.exp()).sum(2).mean()

    def feature_smoothing(self, adj, X):
        adj = (adj.t() + adj) / 2
        rowsum = adj.sum(1)
        r_inv = rowsum.flatten()
        D = torch.diag(r_inv)
        L = D - adj

        r_inv = r_inv + 1e-3
        r_inv = r_inv.pow(-1 / 2).flatten()
        r_inv[torch.isinf(r_inv)] = 0.
        r_mat_inv = torch.diag(r_inv)
        # L = r_mat_inv @ L
        L = r_mat_inv @ L @ r_mat_inv

        XLXT = torch.matmul(torch.matmul(X.t(), L), X)
        loss_smooth_feat = torch.trace(XLXT)
        return loss_smooth_feat

    def loss_pro_gcn(self, estimated_adj, adj, features):
        '''
        reconstruct loss, feature smoothing, symmetric
        :param estimated_adj:
        :param adj:
        :param features:
        :return:
        '''
        lambda_ = 0.1
        phi = 0.1
        alpha = 5e-4
        beta = 1.5

        loss_l1 = torch.norm(estimated_adj, 1)  # ||S|| 1 non-differentiable
        loss_fro = torch.norm(estimated_adj - adj, p='fro')  # ||A - S|| ** 2
        if lambda_:
            loss_smooth_feat = self.feature_smoothing(estimated_adj, features)  # tr(XT L X)
        else:
            loss_smooth_feat = 0 * loss_l1
        loss_symmetric = torch.norm(estimated_adj - estimated_adj.t(), p="fro")
        loss_diffiential = loss_fro + lambda_ * loss_smooth_feat + phi * loss_symmetric
        return loss_l1, loss_diffiential

    def training_step(self, batch, batch_idx, optimizer_idx):
        user, play_list = batch  # bs * item_num
        output, mu, loavar = self(play_list)  # 256*1*item_size
        lossv = self.lossv(output, play_list, 0)
        lossk = self.lossk(mu, loavar)
        loss = lossv + self.alpha * lossk
        self.loss = loss
        return loss

    def on_after_backward(self):
        '''
        l1, nuclear
        :return:
        '''
        optimizer_1, optimizer_2, = self.optimizers()
        clip_gradient(optimizer_1, 1e6)
        clip_gradient(optimizer_2, 1e6)


    def optimizer_step(self,epoch,batch_idx,optimizer,optimizer_idx,optimizer_closure,on_tpu,using_native_amp,using_lbfgs,):
        if optimizer_idx == 2:
            optimizer.step(closure=optimizer_closure)
            self.S = to_dense_adj(self.graph.edge_index, edge_attr=self.graph.edge_attr).view(self.num_item, self.num_item).detach().numpy()
            self.S = torch.tensor(self.S)
            opt = SGD([self.S], momentum=0.9, lr=0.01)
            opt1 = PGD([self.S], proxs=[prox_operators.prox_nuclear], lr=0.01, alphas=[1.5])
            opt2 = PGD([self.S], proxs=[prox_operators.prox_l1], lr=0.01, alphas=[5e-4])
            opt.zero_grad()
            loss_l1, loss_pro_gcn = self.loss_pro_gcn(self.S, self.A, self.x.view(self.num_item, -1))
            loss_pro_gcn.backward()
            opt.step()
            opt1.zero_grad()
            opt1.step()
            loss_nuclear = prox_operators.nuclear_norm
            opt2.zero_grad()
            opt2.step()
            loss = self.loss + loss_pro_gcn + 1.5 * loss_nuclear + 5e-4 * loss_l1
            self.log('my_loss', loss, on_step=True, on_epoch=True, prog_bar=True, logger=True)
            Graph_A = []
            for e in range(self.graph.edge_index.shape[1]):
                i = self.graph.edge_index[0][e]
                j = self.graph.edge_index[1][e]
                sim = self.S[i][j]
                Graph_A.append([sim])
            Graph_A = torch.tensor(Graph_A, dtype=torch.float).reshape(-1)
            self.graph.edge_attr = Graph_A
        else:
            optimizer.step(closure=optimizer_closure)

    def on_before_zero_grad(self, optimizer):
        self.graph.edge_attr.requires_grad = False
        self.graph.edge_attr.clamp_(+0, 1e12)
        self.graph.edge_attr.requires_grad = True

    def test_step(self, batch, batch_idx):
        user, test = batch
        if self.emb is None:
            self.emb = self.gcn(self.graph).cpu()
            self.emb.require_grad = False
        test_acc = acc(test, self.emb, self.num_item, self.topK)
        self.log_dict({'test_acc': test_acc})

    def configure_optimizers(self):
        return SGD(self.gcn.parameters(), lr=1e-2, momentum=0.9), \
               SGD(self.seg.parameters(), lr=1e-2, momentum=0.9)
