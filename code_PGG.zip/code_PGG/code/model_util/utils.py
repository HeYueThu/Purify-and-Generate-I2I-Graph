import torch
import numpy as np
import os
import random
import torch.backends.cudnn as cudnn

def seed_torch(seed=0, cuda=True):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)

    if cuda:
        torch.cuda.manual_seed_all(seed)
        cudnn.deterministic = True
        cudnn.benchmark = False


def adjust_learning_rate(optimizer, optlr, epoch, lrepo):
    lr = optlr * (0.5 ** (epoch // lrepo))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

def clip_gradient(optimizer, grad_clip):
    for group in optimizer.param_groups:
        for param in group["params"]:
            if param.grad is not None:
                param.grad.clamp_(- grad_clip, grad_clip)

def count(X, x):
    for i in X:
        if int(x.item()) == i.item():
            return True
    return False

def acc(test, attr, num_item, pK=1):
    accuracy = 0.
    bttr = attr.norm(dim=1).reshape(-1, 1)
    attm = attr.mm(attr.t())
    bttm = bttr.mm(bttr.t())
    ans = attm / bttm
    for i in range(len(test)):
        nz = torch.nonzero(test[i][:num_item], as_tuple=False).view(-1)
        sum = 0.
        if len(nz) > 3:
            nz = nz[torch.randperm(len(nz))[:3]]
        for j in range(len(nz)):
            x = test[i][:num_item].clone()
            y = nz[j].reshape(-1)
            x[y] = 0

            x = x.reshape(-1, 1)
            xx = (1 - x).mm(x.t())
            bns = ans * xx
            bns = bns.sum(1).reshape(-1)

            if count(bns.argsort(descending=True)[: pK], y):
                sum = sum + 1
        accuracy = accuracy + sum / len(nz)
    accuracy = accuracy / len(test)

    return accuracy