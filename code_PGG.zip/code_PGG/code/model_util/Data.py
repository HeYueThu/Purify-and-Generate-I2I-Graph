import pandas as pd
from surprise import Reader, Dataset, SVD
import numpy as np


class Weights():
    def __init__(self):
        self.algo = SVD(biased=False)

    def train(self, edges):
        reader = Reader(rating_scale=(1, 5))
        traindata = Dataset.load_from_df(edges[[0, 1, 2]], reader)
        self.algo.fit(traindata.build_full_trainset())

    def getweight(self, user, play_list):
        l = []
        for item in play_list:
            est = self.algo.predict(user, item).est
            l.append(est)
        l = np.array(l)
        return l / np.sum(l)